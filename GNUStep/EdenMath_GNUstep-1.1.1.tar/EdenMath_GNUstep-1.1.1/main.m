#import <AppKit/AppKit.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
